/*
 * Copyright (c) 2004
 * Martin Woolley
 * All rights reserved.
 *
 */
package tests.exceptions;

public class EnquireLinkFailedException extends Exception {
	public EnquireLinkFailedException() {
		super();
	}

}
