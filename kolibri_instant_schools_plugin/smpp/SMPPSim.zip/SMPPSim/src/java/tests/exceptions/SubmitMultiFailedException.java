/*
 * Copyright (c) 2004
 * Martin Woolley
 * All rights reserved.
 *
 */
package tests.exceptions;

public class SubmitMultiFailedException extends Exception {
	public SubmitMultiFailedException() {
		super();
	}

}
